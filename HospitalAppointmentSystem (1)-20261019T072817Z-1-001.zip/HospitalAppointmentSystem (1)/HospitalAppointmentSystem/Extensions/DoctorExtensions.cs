using HospitalAppointmentSystem.Models; // Needed to refer to the Doctor class

namespace HospitalAppointmentSystem.Extensions; // Namespace for extension methods

// Extension methods must live in a static, non-generic, top-level class
public static class DoctorExtensions
{
    // Fixed service charge added to every consultation (Rs. 100)
    private const decimal ServiceCharge = 100m;

    // 'this Doctor doctor' makes this an extension method: call it as doctor.CalculateTotalCharge()
    public static decimal CalculateTotalCharge(this Doctor doctor)
    {
        // Total = consultation fee + Rs.100 service charge
        return doctor.ConsultationFee + ServiceCharge;
    }
}
