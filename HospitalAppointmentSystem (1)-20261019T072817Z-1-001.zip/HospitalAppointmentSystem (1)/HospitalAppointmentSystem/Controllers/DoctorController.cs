using HospitalAppointmentSystem.Extensions; // Gives access to CalculateTotalCharge()
using HospitalAppointmentSystem.Models;     // Doctor and AppointmentViewModel
using HospitalAppointmentSystem.Services;   // DoctorService
using Microsoft.AspNetCore.Mvc;             // Controller base class and attributes

namespace HospitalAppointmentSystem.Controllers; // Namespace for controllers

// Controller that lists doctors, shows details and accepts appointment requests
public class DoctorController : Controller
{
    private readonly DoctorService _doctorService; // Service that returns doctor data

    // Constructor injection of DoctorService
    public DoctorController(DoctorService doctorService)
    {
        _doctorService = doctorService; // Save the service for later use
    }

    // GET: /Doctor/Index  (optionally ?specialization=Cardiology)
    public IActionResult Index(string specialization)
    {
        // ---------- SESSION: store the selected specialization ----------
        if (!string.IsNullOrEmpty(specialization))
        {
            HttpContext.Session.SetString("Specialization", specialization); // Save the choice in session
        }
        else if (Request.Query.ContainsKey("specialization"))
        {
            HttpContext.Session.Remove("Specialization"); // User picked "All": clear the saved value
        }

        // Read the specialization back from session (null if never selected)
        string selected = HttpContext.Session.GetString("Specialization");

        // ---------- IMEMORYCACHE: get cached doctor list ----------
        var doctors = _doctorService.GetDoctors(out bool fromCache); // fromCache tells us if cache was used

        // Filter the list if a specialization is stored in session
        if (!string.IsNullOrEmpty(selected))
        {
            doctors = doctors.Where(d => d.Specialization == selected).ToList(); // Keep matching doctors only
        }

        // ---------- COOKIE: read the patient name ----------
        string patientName = Request.Cookies["PatientName"]; // null if the cookie does not exist

        // Pass values to the view using ViewBag
        ViewBag.PatientName = patientName;        // Used for the greeting
        ViewBag.SelectedSpecialization = selected; // Used to show the current filter
        ViewBag.FromCache = fromCache;            // Shows whether data came from cache
        ViewBag.Specializations = _doctorService.GetDoctors(out _) // Distinct specializations for the dropdown
                                    .Select(d => d.Specialization).Distinct().ToList();
        ViewBag.GeneratedAt = DateTime.Now.ToString("HH:mm:ss"); // Time the page was generated

        return View(doctors); // Send the (filtered) list to the Index view
    }

    // GET: /Doctor/Details?id=1
    // ---------- RESPONSE CACHING: cache this page for 60 seconds ----------
    // VaryByQueryKeys makes a separate cached copy for each different 'id' value
    [ResponseCache(Duration = 60, Location = ResponseCacheLocation.Any, VaryByQueryKeys = new[] { "id" })]
    public IActionResult Details(int id) // 'id' is read from the QUERY STRING (?id=1)
    {
        var doctor = _doctorService.GetDoctorById(id); // Look up the doctor

        if (doctor == null)
        {
            return NotFound(); // Return HTTP 404 if no doctor has this id
        }

        ViewBag.TotalCharge = doctor.CalculateTotalCharge(); // Use the extension method
        ViewBag.GeneratedAt = DateTime.Now.ToString("HH:mm:ss"); // Time stamp to prove the page is cached

        return View(doctor); // Show the details view
    }

    // POST: /Doctor/Book  (receives the appointment form)
    [HttpPost] // Only responds to POST requests
    public IActionResult Book(AppointmentViewModel model)
    {
        // model.DoctorId is bound from the HIDDEN FIELD in the form
        var doctor = _doctorService.GetDoctorById(model.DoctorId); // Find the doctor

        if (doctor == null || string.IsNullOrWhiteSpace(model.PatientName))
        {
            return RedirectToAction(nameof(Index)); // Invalid request: go back to the list
        }

        // ---------- COOKIE: store the patient name ----------
        var cookieOptions = new CookieOptions
        {
            Expires = DateTimeOffset.Now.AddDays(7), // Cookie lives for 7 days
            HttpOnly = true,                         // Not accessible from JavaScript
            IsEssential = true                       // Always sent, regardless of consent settings
        };
        Response.Cookies.Append("PatientName", model.PatientName, cookieOptions); // Write the cookie

        model.Doctor = doctor; // Attach the doctor so the confirmation view can display it
        ViewBag.TotalCharge = doctor.CalculateTotalCharge(); // Total charge including service fee

        return View("Confirmation", model); // Show the confirmation page
    }

    // Simple error page action used by the exception handler
    public IActionResult Error()
    {
        return Content("Something went wrong. Please try again."); // Plain text error message
    }
}
