using HospitalAppointmentSystem.Models; // Post model
using Microsoft.AspNetCore.Mvc;         // Controller base class

namespace HospitalAppointmentSystem.Controllers; // Namespace for controllers

// Controller that fetches posts from an external API asynchronously
public class PostsController : Controller
{
    private readonly IHttpClientFactory _httpClientFactory; // Factory that creates HttpClient objects

    // Constructor injection of IHttpClientFactory
    public PostsController(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory; // Store the factory
    }

    // GET: /Posts/Index - 'async Task<IActionResult>' makes the action asynchronous
    public async Task<IActionResult> Index()
    {
        var posts = new List<Post>(); // Empty list used if the request fails

        try
        {
            var client = _httpClientFactory.CreateClient(); // Create an HttpClient

            // 'await' frees the thread while waiting for the web response (non-blocking)
            // GetFromJsonAsync downloads the JSON and converts it into a List<Post>
            posts = await client.GetFromJsonAsync<List<Post>>("https://jsonplaceholder.typicode.com/posts");
        }
        catch (HttpRequestException ex) // Network or HTTP error
        {
            ViewBag.Error = "Could not retrieve posts: " + ex.Message; // Show error to the user
        }

        return View(posts); // Send the posts to the view
    }
}
