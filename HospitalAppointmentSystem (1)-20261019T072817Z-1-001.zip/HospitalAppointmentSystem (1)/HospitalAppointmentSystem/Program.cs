// Create the builder that configures services and the app host
var builder = WebApplication.CreateBuilder(args);

// Register MVC controllers and Razor views
builder.Services.AddControllersWithViews();

// Register IMemoryCache so controllers/services can cache data in server memory
builder.Services.AddMemoryCache();

// Register Response Caching services (needed for the [ResponseCache] attribute to take effect)
builder.Services.AddResponseCaching();

// Register IHttpClientFactory so we can safely create HttpClient objects for web requests
builder.Services.AddHttpClient();

// Session needs a backing store; this one keeps session data in server memory
builder.Services.AddDistributedMemoryCache();

// Register Session services and configure the session
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20); // Session expires after 20 minutes of inactivity
    options.Cookie.HttpOnly = true;                 // Session cookie cannot be read by JavaScript (security)
    options.Cookie.IsEssential = true;              // Cookie is required for the app, so it is always sent
});

// Register our doctor data service (Scoped = one instance per request)
builder.Services.AddScoped<HospitalAppointmentSystem.Services.DoctorService>();

// Build the application using the configured services
var app = builder.Build();

// Use a friendly error page when not in development
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Doctor/Error"); // Redirect unhandled errors to the Error action
}

// Allow serving static files (css, js, images) from wwwroot
app.UseStaticFiles();

// Enable routing so requests are matched to endpoints
app.UseRouting();

// Enable Response Caching middleware (must be before endpoints are executed)
app.UseResponseCaching();

// Enable Session middleware (must be after UseRouting and before endpoints)
app.UseSession();

// Enable authorization middleware (no auth used, but it is standard in the pipeline)
app.UseAuthorization();

// Default route: /Doctor/Index/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Doctor}/{action=Index}/{id?}");

// Start the application and listen for requests
app.Run();
