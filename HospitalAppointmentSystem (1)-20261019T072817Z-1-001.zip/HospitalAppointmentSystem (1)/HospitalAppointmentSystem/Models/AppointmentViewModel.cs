namespace HospitalAppointmentSystem.Models; // Namespace for model classes

// View model carrying the appointment form data and the selected doctor
public class AppointmentViewModel
{
    public int DoctorId { get; set; }       // Filled from the HIDDEN FIELD in the form
    public string PatientName { get; set; } // Patient name typed by the user
    public string Reason { get; set; }      // Reason for the visit
    public Doctor Doctor { get; set; }      // Doctor object used to show confirmation details
}
