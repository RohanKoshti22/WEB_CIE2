namespace HospitalAppointmentSystem.Models; // Namespace for model classes

// Model matching one JSON post returned by jsonplaceholder.typicode.com/posts
public class Post
{
    public int UserId { get; set; }   // Id of the user who wrote the post
    public int Id { get; set; }       // Id of the post (displayed in the table)
    public string Title { get; set; } // Title of the post (displayed in the table)
    public string Body { get; set; }  // Body text of the post (not displayed)
}
