namespace HospitalAppointmentSystem.Models; // Namespace that groups all model classes

// Model class representing a doctor
public class Doctor
{
    public int DoctorId { get; set; }          // Unique identifier of the doctor
    public string DoctorName { get; set; }     // Full name of the doctor
    public string Specialization { get; set; } // Medical field, e.g. Cardiology
    public int Experience { get; set; }        // Years of experience
    public decimal ConsultationFee { get; set; } // Base consultation fee in rupees
}
