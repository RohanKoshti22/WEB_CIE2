using HospitalAppointmentSystem.Models;  // Access the Doctor model
using Microsoft.Extensions.Caching.Memory; // Access IMemoryCache and MemoryCacheEntryOptions

namespace HospitalAppointmentSystem.Services; // Namespace for services

// Service that supplies doctor data, using IMemoryCache to avoid rebuilding the list repeatedly
public class DoctorService
{
    private readonly IMemoryCache _cache;                // Injected in-memory cache
    private const string DoctorListKey = "DoctorListKey"; // Key under which the list is cached

    // Constructor: ASP.NET Core dependency injection supplies IMemoryCache
    public DoctorService(IMemoryCache cache)
    {
        _cache = cache; // Store the cache in the private field
    }

    // Returns the doctor list; fetched from cache if available, otherwise built and cached for 3 minutes
    public List<Doctor> GetDoctors(out bool fromCache)
    {
        // TryGetValue checks the cache; 'out' returns the cached list if found
        if (_cache.TryGetValue(DoctorListKey, out List<Doctor> doctors))
        {
            fromCache = true; // Tell the caller the data came from cache
            return doctors;   // Return the cached list immediately
        }

        fromCache = false; // Cache miss: data will be created now

        // Simulated database data (in a real app this would come from a database)
        doctors = new List<Doctor>
        {
            new Doctor { DoctorId = 1, DoctorName = "Dr. Anil Sharma",  Specialization = "Cardiology",  Experience = 15, ConsultationFee = 800 },
            new Doctor { DoctorId = 2, DoctorName = "Dr. Meera Patel",  Specialization = "Dermatology", Experience = 8,  ConsultationFee = 500 },
            new Doctor { DoctorId = 3, DoctorName = "Dr. Rakesh Mehta", Specialization = "Orthopedics",  Experience = 12, ConsultationFee = 700 },
            new Doctor { DoctorId = 4, DoctorName = "Dr. Sneha Joshi",  Specialization = "Pediatrics",  Experience = 10, ConsultationFee = 600 },
            new Doctor { DoctorId = 5, DoctorName = "Dr. Kiran Desai",  Specialization = "Cardiology",  Experience = 6,  ConsultationFee = 650 }
        };

        // Configure how long the list stays in the cache
        var options = new MemoryCacheEntryOptions()
            .SetAbsoluteExpiration(TimeSpan.FromMinutes(3)); // Entry is removed exactly 3 minutes after creation

        _cache.Set(DoctorListKey, doctors, options); // Save the list in the cache with the options

        return doctors; // Return the freshly built list
    }

    // Finds a single doctor by id (uses the cached list)
    public Doctor GetDoctorById(int id)
    {
        var doctors = GetDoctors(out _); // Get the list; discard the 'fromCache' flag using '_'
        return doctors.FirstOrDefault(d => d.DoctorId == id); // Return matching doctor or null
    }
}
