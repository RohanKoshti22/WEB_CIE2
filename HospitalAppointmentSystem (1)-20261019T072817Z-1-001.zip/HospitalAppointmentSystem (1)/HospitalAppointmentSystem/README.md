# Hospital Appointment Management System (ASP.NET Core MVC, .NET 7.0.410)

## Run
    dotnet restore
    dotnet run
Open the https/http URL shown in the console (default page: /Doctor/Index).

## Where each requirement is implemented
| Requirement | File |
|---|---|
| Doctor model | Models/Doctor.cs |
| CalculateTotalCharge() extension (+₹100) | Extensions/DoctorExtensions.cs |
| Async web request + table | Controllers/PostsController.cs, Views/Posts/Index.cshtml |
| Cookie (patient name) | DoctorController.Book (write) / Index (read) |
| Session (specialization) | DoctorController.Index |
| Query string (DoctorId) | Index view link -> /Doctor/Details?id=1 |
| Hidden field (DoctorId) | Views/Doctor/Details.cshtml |
| Response caching (60s) | [ResponseCache] on DoctorController.Details |
| IMemoryCache, 3 min | Services/DoctorService.cs |
